async function injectRecaptcha() {
    var s = document.createElement('script');
    s.src = "https://www.google.com/recaptcha/api.js?hl=es&render=6LfBEb8UAAAAAC3Tj2jbBeAapky_TfXoNbzeBhJN";
    s.onload = function () {
        console.log('================================================================')
        console.log('ReCAPTCHA Armat')
        //Per a test nomes
        this.remove();
        console.log('================================================================')
    };
    (document.head || document.documentElement).appendChild(s);
}

async function injectRecaptchaSetup() {

    var actualCode = '(' + function () {
        // console.log(grecaptcha)
        grecaptcha.ready(function () {
            grecaptcha.execute("6LfBEb8UAAAAAC3Tj2jbBeAapky_TfXoNbzeBhJN", { action: "acOfertarCita" })
                .then(function (captchaSolution) {
                    console.log('machine_procs  =========================')
                    console.log(captchaSolution);
                    console.log('========================================')
                    document.getElementById('acpIframe').contentWindow.postMessage({
                        classe: "recaptcha-token",
                        token: captchaSolution
                    }, '*')
                });
        });
    } + ')();';
    var script = document.createElement('script');
    script.textContent = actualCode;
    (document.head || document.documentElement).appendChild(script);
}