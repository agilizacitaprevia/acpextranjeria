
async function initializeStatistics(triosmerString) {
    cbl = new CBL({
        preprocess: function (img) {
            // img.debugImage("debugPreprocessed");
            img.cropRelative(22, 2, 22, 2);
            // img.debugImage("debugPreprocessed");
            img.removeTransparency();
            // img.debugImage("debugPreprocessed");
            img.removeLight(16);
            // img.debugImage("debugPreprocessed");
            img.removeHorizontalLine(2);
            // img.debugImage("debugPreprocessed");
            img.colorRegions(50, true, 0);
            // img.debugImage("debugPreprocessed");
        },
        // model_file: "cbl-model.dat",
        model_string: triosmerString,
        character_set: "0123456789abcdefghijklmnopqrstuvwxyz",
        exact_characters_width: 20,
        exact_characters_play: 2,
        exact_characters: 5,
        blob_min_pixels: 50,
        blob_max_pixels: 15000,
        pattern_width: 20,
        pattern_height: 30,
        allow_console_log: true,
        blob_console_debug: true,
        perceptive_colorspace: true,
        // blob_debug: "debugSegmented",
        model_loaded: function () {
            if (ACP_LOG_MODE) console.log("CBL MODEL LOADED");
        }
    });
}

var MD5 = function(d){var r = M(V(Y(X(d),8*d.length)));return r.toLowerCase()};function M(d){for(var _,m="0123456789ABCDEF",f="",r=0;r<d.length;r++)_=d.charCodeAt(r),f+=m.charAt(_>>>4&15)+m.charAt(15&_);return f}function X(d){for(var _=Array(d.length>>2),m=0;m<_.length;m++)_[m]=0;for(m=0;m<8*d.length;m+=8)_[m>>5]|=(255&d.charCodeAt(m/8))<<m%32;return _}function V(d){for(var _="",m=0;m<32*d.length;m+=8)_+=String.fromCharCode(d[m>>5]>>>m%32&255);return _}function Y(d,_){d[_>>5]|=128<<_%32,d[14+(_+64>>>9<<4)]=_;for(var m=1732584193,f=-271733879,r=-1732584194,i=271733878,n=0;n<d.length;n+=16){var h=m,t=f,g=r,e=i;f=md5_ii(f=md5_ii(f=md5_ii(f=md5_ii(f=md5_hh(f=md5_hh(f=md5_hh(f=md5_hh(f=md5_gg(f=md5_gg(f=md5_gg(f=md5_gg(f=md5_ff(f=md5_ff(f=md5_ff(f=md5_ff(f,r=md5_ff(r,i=md5_ff(i,m=md5_ff(m,f,r,i,d[n+0],7,-680876936),f,r,d[n+1],12,-389564586),m,f,d[n+2],17,606105819),i,m,d[n+3],22,-1044525330),r=md5_ff(r,i=md5_ff(i,m=md5_ff(m,f,r,i,d[n+4],7,-176418897),f,r,d[n+5],12,1200080426),m,f,d[n+6],17,-1473231341),i,m,d[n+7],22,-45705983),r=md5_ff(r,i=md5_ff(i,m=md5_ff(m,f,r,i,d[n+8],7,1770035416),f,r,d[n+9],12,-1958414417),m,f,d[n+10],17,-42063),i,m,d[n+11],22,-1990404162),r=md5_ff(r,i=md5_ff(i,m=md5_ff(m,f,r,i,d[n+12],7,1804603682),f,r,d[n+13],12,-40341101),m,f,d[n+14],17,-1502002290),i,m,d[n+15],22,1236535329),r=md5_gg(r,i=md5_gg(i,m=md5_gg(m,f,r,i,d[n+1],5,-165796510),f,r,d[n+6],9,-1069501632),m,f,d[n+11],14,643717713),i,m,d[n+0],20,-373897302),r=md5_gg(r,i=md5_gg(i,m=md5_gg(m,f,r,i,d[n+5],5,-701558691),f,r,d[n+10],9,38016083),m,f,d[n+15],14,-660478335),i,m,d[n+4],20,-405537848),r=md5_gg(r,i=md5_gg(i,m=md5_gg(m,f,r,i,d[n+9],5,568446438),f,r,d[n+14],9,-1019803690),m,f,d[n+3],14,-187363961),i,m,d[n+8],20,1163531501),r=md5_gg(r,i=md5_gg(i,m=md5_gg(m,f,r,i,d[n+13],5,-1444681467),f,r,d[n+2],9,-51403784),m,f,d[n+7],14,1735328473),i,m,d[n+12],20,-1926607734),r=md5_hh(r,i=md5_hh(i,m=md5_hh(m,f,r,i,d[n+5],4,-378558),f,r,d[n+8],11,-2022574463),m,f,d[n+11],16,1839030562),i,m,d[n+14],23,-35309556),r=md5_hh(r,i=md5_hh(i,m=md5_hh(m,f,r,i,d[n+1],4,-1530992060),f,r,d[n+4],11,1272893353),m,f,d[n+7],16,-155497632),i,m,d[n+10],23,-1094730640),r=md5_hh(r,i=md5_hh(i,m=md5_hh(m,f,r,i,d[n+13],4,681279174),f,r,d[n+0],11,-358537222),m,f,d[n+3],16,-722521979),i,m,d[n+6],23,76029189),r=md5_hh(r,i=md5_hh(i,m=md5_hh(m,f,r,i,d[n+9],4,-640364487),f,r,d[n+12],11,-421815835),m,f,d[n+15],16,530742520),i,m,d[n+2],23,-995338651),r=md5_ii(r,i=md5_ii(i,m=md5_ii(m,f,r,i,d[n+0],6,-198630844),f,r,d[n+7],10,1126891415),m,f,d[n+14],15,-1416354905),i,m,d[n+5],21,-57434055),r=md5_ii(r,i=md5_ii(i,m=md5_ii(m,f,r,i,d[n+12],6,1700485571),f,r,d[n+3],10,-1894986606),m,f,d[n+10],15,-1051523),i,m,d[n+1],21,-2054922799),r=md5_ii(r,i=md5_ii(i,m=md5_ii(m,f,r,i,d[n+8],6,1873313359),f,r,d[n+15],10,-30611744),m,f,d[n+6],15,-1560198380),i,m,d[n+13],21,1309151649),r=md5_ii(r,i=md5_ii(i,m=md5_ii(m,f,r,i,d[n+4],6,-145523070),f,r,d[n+11],10,-1120210379),m,f,d[n+2],15,718787259),i,m,d[n+9],21,-343485551),m=safe_add(m,h),f=safe_add(f,t),r=safe_add(r,g),i=safe_add(i,e)}return Array(m,f,r,i)}function md5_cmn(d,_,m,f,r,i){return safe_add(bit_rol(safe_add(safe_add(_,d),safe_add(f,i)),r),m)}function md5_ff(d,_,m,f,r,i,n){return md5_cmn(_&m|~_&f,d,_,r,i,n)}function md5_gg(d,_,m,f,r,i,n){return md5_cmn(_&f|m&~f,d,_,r,i,n)}function md5_hh(d,_,m,f,r,i,n){return md5_cmn(_^m^f,d,_,r,i,n)}function md5_ii(d,_,m,f,r,i,n){return md5_cmn(m^(_|~f),d,_,r,i,n)}function safe_add(d,_){var m=(65535&d)+(65535&_);return(d>>16)+(_>>16)+(m>>16)<<16|65535&m}function bit_rol(d,_){return d<<_|d>>>32-_}

CBL = function (options) {
    var defaults = {
        preprocess: function () {
            warn("You should define a preprocess method!");
        },
        model_file: "",
        model_string: "",
        model_loaded: function () {},
        training_complete: function () {},
        blob_min_pixels: 1,
        blob_max_pixels: 99999,
        blob_min_width: 1,
        blob_min_height: 1,
        blob_max_width: 99999,
        blob_max_height: 99999,
        pattern_width: 20,
        pattern_height: 20,
        pattern_maintain_ratio: false,
        pattern_auto_rotate: false,
        incorrect_segment_char: "\\",
        blob_debug: "",
        blob_console_debug: false,
        allow_console_log: false,
        allow_console_warn: true,
        perceptive_colorspace: false,
        character_set: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789",
        fixed_blob_locations: [], // Expected format: [ { x1: 0, y1: 0, x2: 0, y2: 0 }, ... ]
        exact_characters: -1,
        exact_characters_width: -1, // Used to guess how many characters there are in a large blob
        exact_characters_play: -1 // Used to find a good vertical split point when splitting by an exact number of characters
    };

    options = options || {};
    for (var opt in defaults) {
        if (defaults.hasOwnProperty(opt) && !options.hasOwnProperty(opt)) {
            options[opt] = defaults[opt];
        }
    }

    var obj = {

        /***********************************************\
        | General Methods                               |
        \***********************************************/

        // Load an image and attempt to solve it based on trained model
        solve: function (el) {
            return obj.train(el, true);
        },

        done: function (resultHandler) {
            addQueue(function () {
                resultHandler(doneResult);
                runQueue();
            });
        },

        // Load an image and attempt to solve it based on trained model
        train: function (el, solving) {
            if (typeof solving === 'undefined') {
                solving = false;
            }
            addQueue(function () {
                var image;
                var needSetSrc = false;
                if (document.getElementById(el) != null) {
                    image = document.getElementById(el);
                } else {
                    image = document.createElement("img");
                    needSetSrc = true;
                }
                var afterLoad = function () {
                    var solution = "";
                    var canvas = document.createElement('canvas');
                    canvas.width = image.width;
                    canvas.height = image.height;
                    canvas.getContext('2d').drawImage(image, 0, 0);

                    // Run user-specified image preprocessing
                    var cblImage = new cbl_image(canvas);
                    options.preprocess(cblImage);

                    // Run segmentation
                    var blobs;
                    if (options.fixed_blob_locations.length > 0) {
                        blobs = cblImage.segmentBlocks(options.pattern_width,
                            options.pattern_height,
                            options.fixed_blob_locations,
                            options.blob_debug);
                    } else {
                        blobs = cblImage.segmentBlobs(options.blob_min_pixels,
                            options.blob_max_pixels,
                            options.pattern_width,
                            options.pattern_height,
                            options.blob_debug);
                        // console.log(blobs)
                    }

                    // FOR TRAINING
                    // Set up a list of patterns for a human to classify
                    if (!solving) {
                        for (var i = 0; i < blobs.length; i++) {
                            var imgUrl = blobs[i].toDataURL();
                            var blobPattern = blobToPattern(blobs[i]);
                            pendingPatterns.push({
                                imgSrc: imgUrl,
                                pattern: blobPattern,
                                imgId: patternElementID,
                                txtId: humanSolutionElementID,
                                self: obj,
                                onComplete: options.training_complete
                            });
                        }

                        // Load first pattern
                        if (!currentlyTraining) {
                            obj.loadNextPattern();
                        }
                        currentlyTraining = true;
                    }

                    // FOR SOLVING
                    // Solve an image buy comparing each blob against our model of learned patterns
                    else {
                        for (var i = 0; i < blobs.length; i++) {
                            // console.log(blobs[i])
                            solution += findBestMatch(blobToPattern(blobs[i]));
                        }
                        log("Solution = " + solution);
                    }

                    doneResult = solution;
                    runQueue();
                };
                if (image.complete && !needSetSrc) {
                    afterLoad();
                } else {
                    image.onload = afterLoad;

                    // Set the source AFTER setting the onload
                    if (needSetSrc) {
                        image.src = el;
                        // console.log(image.src)
                    }
                }
            });
            return this;
        },

        // Load the next pattern pending human classification
        loadNextPattern: function () {
            var nextPattern = pendingPatterns.pop();
            if (nextPattern) {
                log("Loading a pattern for human classification.");
                openClassifierDialog();
                document.getElementById(nextPattern.imgId).src = nextPattern.imgSrc;
                document.getElementById(nextPattern.txtId).focus();
                document.getElementById(nextPattern.txtId).onkeyup = function (event) {
                    var typedLetter = document.getElementById(nextPattern.txtId).value;
                    if ((options.character_set.indexOf(typedLetter) > -1 && typedLetter.length) || typedLetter == options.incorrect_segment_char) {
                        if (typedLetter != options.incorrect_segment_char) {
                            model.push({
                                pattern: nextPattern.pattern,
                                solution: document.getElementById(nextPattern.txtId).value
                            });
                            log("Added \"" + document.getElementById(nextPattern.txtId).value + "\" pattern to model!");
                        } else {
                            log("Did not add bad segment to model.");
                        }
                        document.getElementById(nextPattern.txtId).value = "";

                        // Load the next pattern
                        if (pendingPatterns.length) {
                            nextPattern.self.loadNextPattern();
                        } else {
                            currentlyTraining = false;
                            document.getElementById(nextPattern.txtId).onkeyup = function () {};
                            if (typeof nextPattern.onComplete === 'function') {
                                nextPattern.onComplete();
                                closeClassifierDialog();
                            }
                        }
                    } else {
                        document.getElementById(nextPattern.txtId).value = "";
                    }
                };
            }
        },

        // Load a model by deserializing a model string
        loadModelString: function (modelString) {
            modelString = LZString.decompressFromBase64(modelString);
            model = new Array();
            var patterns = modelString.replace(/\[/g, "").split("]");
            for (var i = 0; i < patterns.length; i++) {
                var parts = patterns[i].split("=");
                if (parts.length == 2) {
                    var p = parts[1];
                    var s = parts[0];
                    model.push({
                        pattern: p,
                        solution: s
                    });
                }
            }
            if (!model.length) {
                warn("No patterns to load in provided model.");
            } else {
                log("Model loaded with " + model.length + " patterns!");
                options.model_loaded();
            }
        },

        // Load a model from a file on the server
        loadModel: function (url) {
            try {
                var xhr = new XMLHttpRequest();
                xhr.open("GET", url, true);
                xhr.send();
                xhr.onreadystatechange = function () {
                    if (xhr.readyState == 4 && xhr.status == 200 && xhr.responseText) {
                        obj.loadModelString(xhr.responseText);
                    }
                }
            } catch (err) {
                warn("Could not load model from \"" + url + "\"! (" + err.message + ")");
            }
        },

        // Serialize the model
        serializeModel: function () {
            var str = "";
            for (var i = 0; i < model.length; i++) {
                str += "[" + model[i].solution + "=" + model[i].pattern + "]";
            }
            str = LZString.compressToBase64(str);
            return str;
        },

        // Save the model to a file
        saveModel: function () {
            var str = obj.serializeModel();
            var anchor = document.createElement('a');
            // console.log(str)
            anchor.href = "data:application/octet-stream," + encodeURIComponent(str);
            anchor.setAttribute('download', 'cbl-model.dat');
            anchor.click();
        },

        // Debug stuff about the model
        debugModel: function () {
            for (var i = 0; i < model.length; i++) {
                log(model[i].solution + " pattern length = " + model[i].pattern.split(".").length);
            }
        },

        // Sort the model by pattern solution alphabetically
        sortModel: function () {
            model = model.sort(function (a, b) {
                return a.solution.localeCompare(b.solution);
            });
        },

        // Output the model as images to an element for debugging
        visualizeModel: function (elementId) {
            for (var m = 0; m < model.length; m++) {
                var pattern = document.createElement('canvas');
                pattern.width = options.pattern_width;
                pattern.height = options.pattern_height;
                var pctx = pattern.getContext('2d').getImageData(0, 0, options.pattern_width, options.pattern_height);

                var patternValues = model[m].pattern.split('.');

                for (var x = 0; x < options.pattern_width; x++) {
                    for (var y = 0; y < options.pattern_height; y++) {
                        var i = x * 4 + y * 4 * options.pattern_width;
                        var p = y + x * options.pattern_width;
                        pctx.data[i] = patternValues[p];
                        pctx.data[i + 1] = patternValues[p];
                        pctx.data[i + 2] = patternValues[p];
                        pctx.data[i + 3] = 255;
                    }
                }

                pattern.getContext('2d').putImageData(pctx, 0, 0);

                var test = document.createElement("img");
                test.src = pattern.toDataURL();
                document.getElementById(elementId).appendChild(test);
            }
        },

        // Condense the model by combining patterns with the same solution
        condenseModel: function () {
            var newModel = new Array();
            var oldCount = model.length;
            for (var i = 0; i < model.length; i++) {
                var patternArray = model[i].pattern.split(".");
                var found = false;
                for (var j = 0; j < newModel.length; j++) {
                    // These two patterns have the same solution, so combine the patterns
                    if (newModel[j].solution == model[i].solution) {
                        for (var x = 0; x < newModel[j].tempArray.length; x++) {
                            newModel[j].tempArray[x] = parseInt(newModel[j].tempArray[x]) + parseInt(patternArray[x]);
                        }
                        newModel[j].tempCount++;
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    newModel.push({
                        pattern: model[i].pattern,
                        solution: model[i].solution,
                        tempArray: patternArray,
                        tempCount: 1
                    });
                }
            }
            // Normalize the patterns
            for (var i = 0; i < newModel.length; i++) {
                for (var x = 0; x < newModel[i].tempArray.length; x++) {
                    newModel[i].tempArray[x] = Math.round(newModel[i].tempArray[x] / newModel[i].tempCount);
                }
                newModel[i].pattern = newModel[i].tempArray.join(".");
            }
            model = newModel;
            log("Condensed model from " + oldCount + " patterns to " + model.length + " patterns!");
            return this;
        }
    };

    var cbl_image = function (canvas) {
        var obj = {
            /***********************************************\
            | Image Manipulation Methods                    |
            \***********************************************/

            // Fills each distinct region in the image with a different random color
            colorRegions: function (tolerance, ignoreWhite, pixelJump) {
                if (typeof ignoreWhite === 'undefined') {
                    ignoreWhite = false;
                }
                if (typeof pixelJump === 'undefined') {
                    pixelJump = 0;
                }
                var exclusions = new Array();
                var image = canvas.getContext('2d').getImageData(0, 0, canvas.width, canvas.height);
                for (var x = 0; x < image.width; x++) {
                    for (var y = 0; y < image.height; y++) {
                        var i = x * 4 + y * 4 * image.width;
                        if (!arrayContains(exclusions, i)) {
                            obj.floodfill(x, y, getRandomColor(), tolerance, image, exclusions, ignoreWhite, pixelJump);
                        }
                    }
                }
                canvas.getContext('2d').putImageData(image, 0, 0);
                return this;
            },

            // Display an image in an image tag
            display: function (el) {
                document.getElementById(el).src = canvas.toDataURL();
                return this;
            },

            // Displays the canvas as an image in another element
            debugImage: function (debugElement) {
                var test = document.createElement("img");
                test.crossOrigin = "anonymous"
                test.src = canvas.toDataURL();
                document.getElementById(debugElement).appendChild(test);
                return this;
            },

            // Flood fill a given color into a region starting at a certain point
            floodfill: function (x, y, fillcolor, tolerance, image, exclusions, ignoreWhite, pixelJump) {
                var internalImage = false;
                if (typeof image === 'undefined') {
                    internalImage = true;
                    image = canvas.getContext('2d').getImageData(0, 0, canvas.width, canvas.height);
                }
                if (typeof pixelJump === 'undefined') {
                    pixelJump = 0;
                }
                var data = image.data;
                var length = data.length;
                var Q = [];
                var i = (x + y * image.width) * 4;
                var e = i,
                    w = i,
                    me, mw, w2 = image.width * 4;
                var targetcolor = [data[i], data[i + 1], data[i + 2], data[i + 3]];
                var targettotal = data[i] + data[i + 1] + data[i + 2] + data[i + 3];

                if (!pixelCompare(i, targetcolor, targettotal, fillcolor, data, length, tolerance)) {
                    return false;
                }
                Q.push(i);
                while (Q.length) {
                    i = Q.pop();
                    if (typeof exclusions !== 'undefined') {
                        if (arrayContains(exclusions, i)) {
                            continue;
                        }
                    }
                    if (pixelCompareAndSet(i, targetcolor, targettotal, fillcolor, data, length, tolerance, exclusions, ignoreWhite)) {
                        e = i;
                        w = i;
                        mw = (i / w2) * w2;
                        me = mw + w2;

                        while (mw < (w -= 4) && pixelCompareAndSet(w, targetcolor, targettotal, fillcolor, data, length, tolerance, exclusions, ignoreWhite));
                        while (me > (e += 4) && pixelCompareAndSet(e, targetcolor, targettotal, fillcolor, data, length, tolerance, exclusions, ignoreWhite));

                        if (pixelJump > 0) {
                            // Skip over a certain number of pixels that don't match
                            w -= pixelJump * 4;
                            e += pixelJump * 4;
                        }

                        for (var j = w; j < e; j += 4) {
                            if (j - w2 >= 0 && pixelCompare(j - w2, targetcolor, targettotal, fillcolor, data, length, tolerance)) {
                                Q.push(j - w2);
                            }
                            if (j + w2 < length && pixelCompare(j + w2, targetcolor, targettotal, fillcolor, data, length, tolerance)) {
                                Q.push(j + w2);
                            }
                        }
                    }
                }
                if (internalImage) {
                    canvas.getContext('2d').putImageData(image, 0, 0);
                }
            },

            // Blur the image (box blur)
            blur: function (level) {
                if (typeof level === 'undefined') {
                    level = 1;
                }

                if (level == 2) {
                    return this.convolute([
                        [1, 1, 1, 1, 1],
                        [1, 1, 1, 1, 1],
                        [1, 1, 1, 1, 1],
                        [1, 1, 1, 1, 1],
                        [1, 1, 1, 1, 1]
                    ], 1.0 / 25);
                } else if (level == 3) {
                    return this.convolute([
                        [1, 1, 1, 1, 1, 1, 1],
                        [1, 1, 1, 1, 1, 1, 1],
                        [1, 1, 1, 1, 1, 1, 1],
                        [1, 1, 1, 1, 1, 1, 1],
                        [1, 1, 1, 1, 1, 1, 1],
                        [1, 1, 1, 1, 1, 1, 1],
                        [1, 1, 1, 1, 1, 1, 1]
                    ], 1.0 / 49);
                } else {
                    return this.convolute([
                        [1, 1, 1],
                        [1, 1, 1],
                        [1, 1, 1]
                    ], 1.0 / 9);
                }
            },

            // Sharpen
            sharpen: function () {
                return this.convolute([
                    [0, -1, 0],
                    [-1, 5, -1],
                    [0, -1, 0]
                ]);
            },

            // Convert the image to grayscale
            grayscale: function () {
                var image = canvas.getContext('2d').getImageData(0, 0, canvas.width, canvas.height);
                for (var x = 0; x < image.width; x++) {
                    for (var y = 0; y < image.height; y++) {
                        var i = x * 4 + y * 4 * image.width;
                        var brightness = 0.34 * image.data[i] + 0.5 * image.data[i + 1] + 0.16 * image.data[i + 2];
                        image.data[i] = brightness;
                        image.data[i + 1] = brightness;
                        image.data[i + 2] = brightness;
                        image.data[i + 3] = 255;
                    }
                }
                canvas.getContext('2d').putImageData(image, 0, 0);
                return this;
            },

            // Change all semi-gray colors to white
            removeGray: function (tolerance) {
                var image = canvas.getContext('2d').getImageData(0, 0, canvas.width, canvas.height);
                for (var x = 0; x < image.width; x++) {
                    for (var y = 0; y < image.height; y++) {
                        var i = x * 4 + y * 4 * image.width;
                        var diff = Math.max(Math.abs(image.data[i] - image.data[i + 1]),
                            Math.abs(image.data[i + 1] - image.data[i + 2]),
                            Math.abs(image.data[i + 2] - image.data[i]));
                        if (diff < tolerance) {
                            image.data[i] = 255;
                            image.data[i + 1] = 255;
                            image.data[i + 2] = 255;
                            image.data[i + 3] = 255;
                        }
                    }
                }
                canvas.getContext('2d').putImageData(image, 0, 0);
                return this;
            },

            // Change all colors above a certain brightness to white
            removeLight: function (brightness) {
                var image = canvas.getContext('2d').getImageData(0, 0, canvas.width, canvas.height);
                for (var x = 0; x < image.width; x++) {
                    for (var y = 0; y < image.height; y++) {
                        var i = x * 4 + y * 4 * image.width;
                        var diff = Math.max(image.data[i], image.data[i + 1], image.data[i + 2]);
                        if (diff > brightness) {
                            image.data[i] = 255;
                            image.data[i + 1] = 255;
                            image.data[i + 2] = 255;
                            image.data[i + 3] = 255;
                        }
                    }
                }
                canvas.getContext('2d').putImageData(image, 0, 0);
                return this;
            },

            // Convert the image to black and white given a grayscale threshold
            binarize: function (threshold) {
                var image = canvas.getContext('2d').getImageData(0, 0, canvas.width, canvas.height);
                for (var x = 0; x < image.width; x++) {
                    for (var y = 0; y < image.height; y++) {
                        var i = x * 4 + y * 4 * image.width;
                        var brightness = 0.34 * image.data[i] + 0.5 * image.data[i + 1] + 0.16 * image.data[i + 2];
                        image.data[i] = brightness >= threshold ? 255 : 0;
                        image.data[i + 1] = brightness >= threshold ? 255 : 0;
                        image.data[i + 2] = brightness >= threshold ? 255 : 0;
                        image.data[i + 3] = 255;
                    }
                }
                canvas.getContext('2d').putImageData(image, 0, 0);
                return this;
            },

            // Apply a convolution filter
            convolute: function (matrix, factor) {
                var image = canvas.getContext('2d').getImageData(0, 0, canvas.width, canvas.height);
                var out = canvas.getContext('2d').getImageData(0, 0, canvas.width, canvas.height);
                var w = matrix[0].length;
                var h = matrix.length;
                var half = Math.floor(h / 2);
                if (typeof factor === 'undefined') {
                    factor = 1;
                }
                var bias = 0;

                for (var y = 0; y < image.height - 1; y++) {
                    for (var x = 0; x < image.width - 1; x++) {
                        var px = x * 4 + y * 4 * image.width;
                        var r = 0;
                        var g = 0;
                        var b = 0;

                        for (var cy = 0; cy < w; cy++) {
                            for (var cx = 0; cx < h; cx++) {
                                var cpx = ((y + (cy - half)) * image.width + (x + (cx - half))) * 4;
                                r += image.data[(cpx + image.data.length) % image.data.length] * matrix[cy][cx];
                                g += image.data[(cpx + 1 + image.data.length) % image.data.length] * matrix[cy][cx];
                                b += image.data[(cpx + 2 + image.data.length) % image.data.length] * matrix[cy][cx];
                            }
                        }

                        out.data[px + 0] = factor * r + bias;
                        out.data[px + 1] = factor * g + bias;
                        out.data[px + 2] = factor * b + bias;
                        out.data[px + 3] = 255;
                    }
                }

                canvas.getContext('2d').putImageData(out, 0, 0);
                return this;
            },

            // Apply an erosion filter
            erode: function () {
                return this.convolute([
                    [-1, -1, -1],
                    [-1, 8, -1],
                    [-1, -1, -1]
                ]);
            },

            // Apply an specific filter to each pixel
            // The filter method should accept and return one parameter that will have three properties: r, g, and b
            // foreach(function (p) { return p; })
            foreach: function (filter) {
                var image = canvas.getContext('2d').getImageData(0, 0, canvas.width, canvas.height);
                for (var x = 0; x < image.width; x++) {
                    for (var y = 0; y < image.height; y++) {
                        var i = x * 4 + y * 4 * image.width;
                        var pixel = {
                            r: image.data[i + 0],
                            g: image.data[i + 1],
                            b: image.data[i + 2]
                        };

                        pixel = filter(pixel);

                        image.data[i + 0] = pixel.r;
                        image.data[i + 1] = pixel.g;
                        image.data[i + 2] = pixel.b;
                        image.data[i + 3] = 255;
                    }
                }
                canvas.getContext('2d').putImageData(image, 0, 0);
                return this;
            },

            // Replace transparent pixels with a solid color
            removeTransparency: function (opacity, color) {
                if (typeof opacity === 'undefined') {
                    opacity = 128;
                }
                if (typeof color === 'undefined') {
                    color = {
                        r: 255,
                        g: 255,
                        b: 255
                    };
                }
                var image = canvas.getContext('2d').getImageData(0, 0, canvas.width, canvas.height);
                for (var x = 0; x < image.width; x++) {
                    for (var y = 0; y < image.height; y++) {
                        var i = x * 4 + y * 4 * image.width;
                        if (image.data[i + 3] <= opacity) {
                            image.data[i + 0] = color.r;
                            image.data[i + 1] = color.g;
                            image.data[i + 2] = color.b;
                            image.data[i + 3] = 255;
                        }
                    }
                }
                canvas.getContext('2d').putImageData(image, 0, 0);
                return this;
            },

            // Invert the color of every pixel
            invert: function (filter) {
                return this.foreach(function (p) {
                    p.r = 255 - p.r;
                    p.g = 255 - p.g;
                    p.b = 255 - p.b;
                    return p;
                });
            },

            // Crop an image
            cropRelative: function (left, top, right, bottom) {
                var image = canvas.getContext('2d').getImageData(left, top, canvas.width - left - right, canvas.height - top - bottom);
                canvas.width = canvas.width - left - right;
                canvas.height = canvas.height - top - bottom;
                canvas.getContext('2d').putImageData(image, 0, 0);
                return this;
            },

            // Remove a horizontal line from the image (must span the entire picture width)
            removeHorizontalLine: function (lineWidth, color) {
                if (typeof color === 'undefined') {
                    color = {
                        r: 0,
                        g: 0,
                        b: 0
                    };
                }
                if (typeof lineWidth === 'undefined') {
                    lineWidth = 1;
                }
                var image = canvas.getContext('2d').getImageData(0, 0, canvas.width, canvas.height);
                var play = [0, -1, 1];
                // Get all the possible line starts
                var starts = [];
                for (var y = 0; y < canvas.height; y++) {
                    var pixel = this.getPixel(0, y);
                    if (pixel.r == color.r && pixel.g == color.g && pixel.b == color.b) {
                        starts.push({
                            x: 0,
                            y: y
                        });
                    }
                }
                // Get all the possible line ends
                var ends = [];
                for (var y = 0; y < canvas.height; y++) {
                    var pixel = this.getPixel(canvas.width - 1, y);
                    if (pixel.r == color.r && pixel.g == color.g && pixel.b == color.b) {
                        ends.push({
                            x: canvas.width - 1,
                            y: y
                        });
                    }
                }

                // Find a line which connects at least one start with at least one end (with the fewest vertical movements possible)
                var self = this;
                var maxSearch = 10000;
                var dead = [];
                var search = function (x, y, line) {
                    if (false) {
                        // Debug
                        var i = x * 4 + y * 4 * image.width;
                        image.data[i + 0] = 255;
                        image.data[i + 1] = 0;
                        image.data[i + 2] = 0;
                        image.data[i + 3] = 255;
                    }
                    if (maxSearch-- <= 0) {
                        return null;
                    }
                    var allLines = [];
                    var copy = JSON.parse(JSON.stringify(line));
                    copy.points.push({
                        x: x,
                        y: y
                    });
                    if (x >= canvas.width - 1 && ends.some(function (e) {
                            return e.x == copy.points[copy.points.length - 1].x && e.y == copy.points[copy.points.length - 1].y;
                        })) {
                        return copy;
                    }
                    var pixel = self.getPixel(x, y);
                    if (pixel.r != color.r || pixel.g != color.g || pixel.b != color.b) {
                        return null;
                    }
                    for (var d = 0; d < play.length; d++) {
                        if (y + play[d] >= 0 && y + play[d] < canvas.height) {
                            copy.vertical += Math.abs(play[d]);
                            if (dead.some(function (e) {
                                    return e.x == x + 1 && e.y == y + play[d];
                                })) {
                                // Don't revisit dead nodes
                                continue;
                            }
                            var subLine = search(x + 1, y + play[d], copy);
                            if (subLine != null) {
                                allLines.push(subLine);
                                // Return the first one we find
                                return subLine;
                            } else {
                                dead.push({
                                    x: x + 1,
                                    y: y + play[d]
                                });
                            }
                        }
                    }
                    return allLines && allLines.length ? allLines.reduce(function (a, b) {
                        return a.vertical < b.vertical ? a : b;
                    }) : null;
                };
                // Remove the lines
                for (var s = 0; s < starts.length; s++) {
                    var line = search(starts[s].x, starts[s].y, {
                        points: [],
                        vertical: 0
                    });

                    if (line && line.points) {
                        for (var p = 0; p < line.points.length; p++) {
                            for (var w = -lineWidth; w <= lineWidth; w++) {
                                var i = line.points[p].x * 4 + (line.points[p].y + w) * 4 * image.width;
                                var k = line.points[p].x * 4 + (line.points[p].y + w - 1) * 4 * image.width;
                                image.data[i + 0] = image.data[k + 0];
                                image.data[i + 1] = image.data[k + 1];
                                image.data[i + 2] = image.data[k + 2];
                                image.data[i + 3] = 255;
                            }
                        }
                    }
                }
                canvas.getContext('2d').putImageData(image, 0, 0);
                return this;
            },

            /***********************************************\
            | Image Helper Methods                          |
            \***********************************************/

            // Get the R, G, and B values of a pixel at a given location in the image
            // Returned object is in the format { r: 0, g: 0, b: 0 }
            getPixel: function (x, y) {
                var image = canvas.getContext('2d').getImageData(0, 0, canvas.width, canvas.height);
                var i = x * 4 + y * 4 * image.width;
                var pixel = {
                    r: image.data[i + 0],
                    g: image.data[i + 1],
                    b: image.data[i + 2]
                };
                return pixel;
            },

            /***********************************************\
            | Image Segmentation Methods                    |
            \***********************************************/

            // Cut the image into separate, pre-defined sections
            segmentBlocks: function (segmentWidth, segmentHeight, segmentLocations, debugElement) {
                if (typeof segmentWidth === 'undefined') {
                    segmentWidth = 20;
                }
                if (typeof segmentHeight === 'undefined') {
                    segmentHeight = 20;
                }
                if (typeof segmentLocations === 'undefined') {
                    segmentLocations = [];
                }

                var image = canvas.getContext('2d').getImageData(0, 0, canvas.width, canvas.height);

                // Create blobs
                var blobs = new Array();
                for (var c = 0; c < segmentLocations.length; c++) {
                    var blob = document.createElement('canvas');
                    blob.width = image.width;
                    blob.height = image.height;
                    var blobContext = blob.getContext('2d').getImageData(0, 0, canvas.width, canvas.height);
                    var blobData = blobContext.data;
                    var pixels = 0;
                    var leftmost = segmentLocations[c].x1;
                    var rightmost = segmentLocations[c].x2;
                    var topmost = segmentLocations[c].y1;
                    var bottommost = segmentLocations[c].y2;

                    // Scale, crop, and resize blobs
                    var temp = document.createElement('canvas');
                    temp.width = rightmost - leftmost + 1;
                    temp.height = bottommost - topmost + 1;
                    temp.getContext('2d').putImageData(image, -leftmost, -topmost, leftmost, topmost, temp.width, temp.height);
                    blob.width = segmentWidth;
                    blob.height = segmentHeight;
                    if (options.pattern_maintain_ratio) {
                        var dWidth = temp.width;
                        var dHeight = temp.height;
                        if (dWidth / segmentWidth > dHeight / segmentHeight) {
                            // Scale width
                            blob.getContext('2d').drawImage(temp, 0, 0, segmentWidth, dHeight * (segmentWidth / dWidth));
                        } else {
                            // Scale height
                            blob.getContext('2d').drawImage(temp, 0, 0, dWidth * (segmentHeight / dHeight), segmentHeight);
                        }
                    } else {
                        // Stretch the image
                        blob.getContext('2d').drawImage(temp, 0, 0, segmentWidth, segmentHeight);
                    }

                    blobs.push(blob);

                    // Debugging help
                    if (typeof debugElement !== 'undefined' && debugElement.length) {
                        if (options.blob_console_debug) {
                            log("Blob size = " + pixels);
                        }
                        var test = document.createElement("img");
                        test.src = blob.toDataURL();
                        document.getElementById(debugElement).appendChild(test);
                    }
                }

                return blobs;
            },

            // Cut the image into separate blobs where each distinct color is a blob
            segmentBlobs: function (minPixels, maxPixels, segmentWidth, segmentHeight, debugElement) {
                if (typeof minPixels === 'undefined') {
                    minPixels = 1;
                }
                if (typeof maxPixels === 'undefined') {
                    maxPixels = 100000;
                }
                if (typeof segmentWidth === 'undefined') {
                    segmentWidth = 20;
                }
                if (typeof segmentHeight === 'undefined') {
                    segmentHeight = 20;
                }

                var image = canvas.getContext('2d').getImageData(0, 0, canvas.width, canvas.height);
                var toColor = function (d, i) {
                    return d[i] * 255 * 255 + d[i + 1] * 256 + d[i + 2];
                };
                var white = toColor([255, 255, 255], 0);

                // Find distinct colors
                var colors = new Array();
                for (var x = 0; x < image.width; x++) {
                    for (var y = 0; y < image.height; y++) {
                        var i = x * 4 + y * 4 * image.width;
                        var rgb = toColor(image.data, i);
                        if (!arrayContains(colors, rgb) && rgb != white) {
                            colors.push(rgb);
                        }
                    }
                }

                // Create blobs
                var blobs = new Array();
                for (var c = 0; c < colors.length; c++) {
                    var blob = document.createElement('canvas');
                    blob.width = image.width;
                    blob.height = image.height;
                    var blobContext = blob.getContext('2d').getImageData(0, 0, canvas.width, canvas.height);
                    var blobData = blobContext.data;
                    var pixels = 0;
                    var leftmost = image.width;
                    var rightmost = 0;
                    var topmost = image.height;
                    var bottommost = 0;

                    for (var x = 0; x < image.width; x++) {
                        for (var y = 0; y < image.height; y++) {
                            var i = x * 4 + y * 4 * image.width;
                            var rgb = toColor(image.data, i);
                            if (rgb == colors[c]) {
                                blobData[i] = 0;
                                blobData[i + 1] = 0;
                                blobData[i + 2] = 0;
                                blobData[i + 3] = 255;

                                pixels++;

                                if (x < leftmost) {
                                    leftmost = x;
                                }
                                if (x > rightmost) {
                                    rightmost = x;
                                }
                                if (y < topmost) {
                                    topmost = y;
                                }
                                if (y > bottommost) {
                                    bottommost = y;
                                }
                            } else {
                                blobData[i] = 255;
                                blobData[i + 1] = 255;
                                blobData[i + 2] = 255;
                                blobData[i + 3] = 255;
                            }
                        }
                    }

                    // Only save blobs of a certain size
                    if (pixels >= minPixels && pixels <= maxPixels &&
                        rightmost - leftmost >= options.blob_min_width &&
                        bottommost - topmost >= options.blob_min_height &&
                        rightmost - leftmost <= options.blob_max_width &&
                        bottommost - topmost <= options.blob_max_height) {
                        // Scale, crop, and resize blobs
                        var temp = document.createElement('canvas');
                        temp.width = rightmost - leftmost + 1;
                        temp.height = bottommost - topmost + 1;
                        temp.getContext('2d').putImageData(blobContext, -leftmost, -topmost, leftmost, topmost, temp.width, temp.height);
                        blob.width = segmentWidth;
                        blob.height = segmentHeight;
                        blob.orig_width = temp.width;
                        blob.orig_image = temp;
                        if (options.pattern_maintain_ratio) {
                            var dWidth = temp.width;
                            var dHeight = temp.height;
                            if (dWidth / segmentWidth > dHeight / segmentHeight) {
                                // Scale width
                                blob.getContext('2d').drawImage(temp, 0, 0, segmentWidth, dHeight * (segmentWidth / dWidth));
                            } else {
                                // Scale height
                                blob.getContext('2d').drawImage(temp, 0, 0, dWidth * (segmentHeight / dHeight), segmentHeight);
                            }
                        } else {
                            // Stretch the image
                            blob.getContext('2d').drawImage(temp, 0, 0, segmentWidth, segmentHeight);
                        }

                        // Rotate the blobs using a histogram to minimize the width of non-white pixels
                        if (options.pattern_auto_rotate) {
                            blob = obj.histogramRotate(blob);
                        }

                        blobs.push(blob);
                    }
                }

                // Make sure we have exactly N blobs if we know there are N characters
                if (options.exact_characters > 0) {
                    // Split the largest blob into two
                    while (blobs.length < options.exact_characters) {
                        var largestIndex = 0;
                        var largest = blobs[0].orig_width;
                        for (var i = 1; i < blobs.length; i++) {
                            if (blobs[i].orig_width > largest) {
                                largest = blobs[i].orig_width;
                                largestIndex = i;
                            }
                        }

                        // How many blobs should this one large blob be split into?
                        var resultingBlobs = 2;
                        if (options.exact_characters_width > 0) {
                            resultingBlobs = Math.ceil(largest / options.exact_characters_width);
                            resultingBlobs = Math.max(resultingBlobs, 2);
                            resultingBlobs = Math.min(resultingBlobs, options.exact_characters - blobs.length + 1);
                        }

                        for (var split = 1; split <= resultingBlobs; split++) {
                            var splitSection = cloneCanvas(blobs[largestIndex].orig_image);
                            var blobContext = splitSection.getContext('2d').getImageData(0, 0, splitSection.width, splitSection.height);

                            var slice = splitSection.width / resultingBlobs;

                            leftmost = Math.floor(slice * (split - 1));
                            rightmost = Math.floor(slice * split);
                            topmost = 0;
                            bottommost = splitSection.height;

                            // How far to look for the best vertical split point
                            if (options.exact_characters_play > 0) {
                                // Find the best left cut
                                var bestLeft = 0;
                                var bestLeftX = 0;
                                for (var fpx = leftmost - options.exact_characters_play; fpx < leftmost + options.exact_characters_play; fpx++) {
                                    var currentLeft = 0;
                                    for (var fpy = topmost; fpy < bottommost; fpy++) {
                                        var fpix = getPixel(blobContext, fpx, fpy);
                                        if (fpix.r == 255 && fpix.g == 255 && fpix.b == 255) {
                                            currentLeft++;
                                        }
                                    }
                                    if (currentLeft > bestLeft) {
                                        bestLeftX = fpx;
                                        bestLeft = currentLeft;
                                    }
                                }
                                leftmost = bestLeftX;

                                // Find the best right cut
                                var bestRight = 0;
                                var bestRightX = 0;
                                for (var fpx = rightmost + options.exact_characters_play; fpx > rightmost - options.exact_characters_play; fpx--) {
                                    var currentRight = 0;
                                    for (var fpy = topmost; fpy < bottommost; fpy++) {
                                        var fpix = getPixel(blobContext, fpx, fpy);
                                        if (fpix.r == 255 && fpix.g == 255 && fpix.b == 255) {
                                            currentRight++;
                                        }
                                    }
                                    if (currentRight > bestRight) {
                                        bestRightX = fpx;
                                        bestRight = currentRight;
                                    }
                                }
                                rightmost = bestRightX;
                            }

                            // Find the highest pixel that's not the background color
                            for (var fpy = topmost; fpy < bottommost && topmost == 0; fpy++) {
                                for (var fpx = leftmost; fpx < rightmost && topmost == 0; fpx++) {
                                    var fpix = getPixel(blobContext, fpx, fpy);
                                    if (fpix.r != 255 || fpix.g != 255 || fpix.b != 255) {
                                        topmost = fpy;
                                    }
                                }
                            }
                            // Find the lowest pixel that's not the background color
                            for (var fpy = bottommost - 1; fpy > topmost && bottommost == splitSection.height; fpy--) {
                                for (var fpx = leftmost; fpx < rightmost && bottommost == splitSection.height; fpx++) {
                                    var fpix = getPixel(blobContext, fpx, fpy);
                                    if (fpix.r != 255 || fpix.g != 255 || fpix.b != 255) {
                                        bottommost = fpy;
                                    }
                                }
                            }

                            // Split the largest image
                            var temp = document.createElement('canvas');
                            temp.width = rightmost - leftmost + 1;
                            temp.height = bottommost - topmost + 1;
                            temp.getContext('2d').putImageData(blobContext, -leftmost, -topmost, leftmost, topmost, temp.width, temp.height);
                            splitSection.width = segmentWidth;
                            splitSection.height = segmentHeight;
                            splitSection.orig_width = temp.width;
                            splitSection.orig_image = temp;
                            if (options.pattern_maintain_ratio) {
                                var dWidth = temp.width;
                                var dHeight = temp.height;
                                if (dWidth / segmentWidth > dHeight / segmentHeight) {
                                    // Scale width
                                    splitSection.getContext('2d').drawImage(temp, 0, 0, segmentWidth, dHeight * (segmentWidth / dWidth));
                                } else {
                                    // Scale height
                                    splitSection.getContext('2d').drawImage(temp, 0, 0, dWidth * (segmentHeight / dHeight), segmentHeight);
                                }
                            } else {
                                // Stretch the image
                                splitSection.getContext('2d').drawImage(temp, 0, 0, segmentWidth, segmentHeight);
                            }

                            // Rotate the blobs using a histogram to minimize the width of non-white pixels
                            if (options.pattern_auto_rotate) {
                                splitSection = obj.histogramRotate(splitSection);
                            }

                            // Must insert into the same location to preserve order
                            blobs.splice(largestIndex + split, 0, splitSection);
                        }

                        blobs.splice(largestIndex, 1);

                        if (options.blob_console_debug) {
                            log("Large blob divided");
                        }
                    }
                    // Remove the smallest blobs
                    while (blobs.length > options.exact_characters) {
                        var smallestIndex = 0;
                        var smallest = blobs[0].orig_width;
                        for (var i = 1; i < blobs.length; i++) {
                            if (blobs[i].orig_width < smallest) {
                                smallest = blobs[i].orig_width;
                                smallestIndex = i;
                            }
                        }
                        blobs.splice(smallestIndex, 1);
                        if (options.blob_console_debug) {
                            log("Small blob removed");
                        }
                    }
                }

                // Debugging help
                if (typeof debugElement !== 'undefined' && debugElement.length) {
                    for (var i = 0; i < blobs.length; i++) {
                        if (options.blob_console_debug) {
                            log("Blob size = " + pixels);
                        }
                        var test = document.createElement("img");
                        test.src = blobs[i].toDataURL();
                        // test.border = 1;
                        document.getElementById(debugElement).appendChild(test);
                    }
                }

                return blobs;
            },

            histogramRotate: function (blob) {
                var initial = new Image();
                initial.src = blob.toDataURL();

                var range = 90;
                var resolution = 5;
                var best = blob;
                var bestWidth = blob.width;
                for (var degrees = -range / 2; degrees <= range / 2; degrees += resolution) {
                    var test = document.createElement('canvas');
                    var testctx = test.getContext('2d');
                    test.width = blob.width;
                    test.height = blob.height;
                    testctx.save();
                    testctx.translate(blob.width / 2, blob.height / 2);
                    testctx.rotate(degrees * Math.PI / 180);
                    testctx.drawImage(initial, -initial.width / 2, -initial.width / 2);
                    testctx.restore();
                    var testImage = testctx.getImageData(0, 0, test.width, test.height)

                    // Check width of non-white pixels
                    var testWidth = 0;
                    for (var x = 0; x < testImage.width; x++) {
                        for (var y = 0; y < testImage.height; y++) {
                            var i = x * 4 + y * 4 * testImage.width;
                            if (testImage.data[i] != 255 && testImage.data[i + 3] != 0) {
                                //  Found a non-white pixel in this column
                                testWidth++;
                                break;
                            }

                            // testImage.data[i] = testImage.data[i + 3] = 255;
                            // testImage.data[i + 1] = testImage.data[i + 2] = 0;
                        }
                    }

                    testctx.putImageData(testImage, 0, 0);

                    // Minimize the number of non-white columns
                    if (testWidth < bestWidth) {
                        bestWidth = testWidth;
                        best = test;
                    }

                    // var test2 = document.createElement("img");
                    // test2.src = test.toDataURL();
                    // document.getElementById("debugPreprocessed").appendChild(test2);
                }
                return best;
            }
        };
        return obj;
    };

    /***********************************************\
    | Private Variables and Helper Methods          |
    \***********************************************/

    var model = new Array();
    var pendingPatterns = new Array();
    var currentlyTraining = false;

    var processQueue = new Array();
    var processBusy = false;
    var doneResult = "";

    // Add a method to the process queue and run the first item if nothing's already running
    var addQueue = function (action) {
        processQueue.push(action);
        if (!processBusy) {
            runQueue();
        }
    };

    // Run the next process in the queue if one is not already running
    var runQueue = function () {
        if (processQueue.length) {
            processBusy = true;
            processQueue.shift()();
        } else {
            processBusy = false;
        }
    };

    // Find the best match for a pattern in the current model
    var findBestMatch = function (pattern) {
        var best = 4000000000;
        var solution = "?";
        for (var i = 0; i < model.length; i++) {
            var test = getPatternDifference(model[i].pattern, pattern);
            if (test < best) {
                best = test;
                solution = model[i].solution;
            }
        }
        return solution;
    };

    // Convert a blob to a pattern object
    var blobToPattern = function (blob) {
        var pattern = new Array();
        var image = blob.getContext('2d').getImageData(0, 0, blob.width, blob.height);
        for (var x = 0; x < image.width; x++) {
            for (var y = 0; y < image.height; y++) {
                var i = x * 4 + y * 4 * image.width;
                var brightness = Math.round(0.34 * image.data[i] + 0.5 * image.data[i + 1] + 0.16 * image.data[i + 2]);
                if (image.data[i + 3] < 255) {
                    brightness = 255;
                }
                pattern.push(brightness);
            }
        }
        return pattern.join('.');
    };

    // Clone a canvas object
    var cloneCanvas = function (oldCanvas) {
        var newCanvas = document.createElement('canvas');
        var context = newCanvas.getContext('2d');
        newCanvas.width = oldCanvas.width;
        newCanvas.height = oldCanvas.height;
        context.drawImage(oldCanvas, 0, 0);
        return newCanvas;
    };

    // Get a value indicating how different two patterns are using the root mean square distance formula
    var getPatternDifference = function (p1, p2) {
        var pattern1 = p1.split('.');
        var pattern2 = p2.split('.');
        var diff = 0;
        for (var i = 0; i < pattern1.length; i++) {
            diff += (pattern1[i] - pattern2[i]) * (pattern1[i] - pattern2[i]);
        }
        return Math.sqrt(diff / pattern1.length);
    };

    // Compare two pixels
    var pixelCompare = function (i, targetcolor, targettotal, fillcolor, data, length, tolerance) {
        // Out of bounds?
        if (i < 0 || i >= length) {
            return false;
        }

        var cNew = dataToColor(targetcolor, 0);
        var cOld = dataToColor(data, i);
        var cFill = fillcolor;

        // Already filled?
        if (colorCompareMaxRGB(cNew, cFill) == 0) {
            return false;
        } else if (colorCompareMaxRGB(cNew, cOld) == 0) {
            return true;
        }

        // Compare colors
        if (options.perceptive_colorspace) {
            // LAB comparison
            if (colorComparePerceptive(cNew, cOld) <= tolerance) {
                return true;
            }
        } else {
            // RGB comparison
            if (colorCompareMaxRGB(cNew, cOld) <= tolerance) {
                return true;
            }
        }

        // No match
        return false;
    };

    // Compare two pixels and set the value if within set rules
    var pixelCompareAndSet = function (i, targetcolor, targettotal, fillcolor, data, length, tolerance, exclusions, ignoreWhite) {
        if (pixelCompare(i, targetcolor, targettotal, fillcolor, data, length, tolerance)) {
            if (typeof exclusions !== 'undefined') {
                if (arrayContains(exclusions, i)) {
                    return false;
                }
            }

            if (!(ignoreWhite && data[i] == 255 && data[i + 1] == 255 && data[i + 2] == 255)) {
                data[i] = fillcolor.r;
                data[i + 1] = fillcolor.g;
                data[i + 2] = fillcolor.b;
                data[i + 3] = fillcolor.a;
            }

            if (typeof exclusions !== 'undefined') {
                exclusions.push(i);
            }
            return true;
        }
        return false;
    };

    var dataToColor = function (data, i) {
        return {
            r: data[i],
            g: data[i + 1],
            b: data[i + 2]
        };
    };

    // Measure the difference between two colors in the RGB colorspace using Root Mean Square
    var colorCompareMaxRGB = function (color1, color2) {
        return Math.sqrt((Math.pow(color1.r - color2.r, 2), Math.pow(color1.g - color2.g, 2), Math.pow(color1.g - color2.g, 2)) / 3);
    };

    // Measure the difference between two colors as measured by the human eye.
    // The "just noticeable difference" (JND) is about 2.3.
    var colorComparePerceptive = function (color1, color2) {
        // Measure the difference between two colors in the LAB colorspace (a perceptive colorspace)
        var eDelta = function (color1, color2) {
            var a = toLAB(toXYZ(color1));
            var b = toLAB(toXYZ(color2));
            return Math.sqrt(Math.pow(a.l - b.l, 2) + Math.pow(a.a - b.a, 2) + Math.pow(a.b - b.b, 2));
        };

        // Convert a color in the RGB colorspace to the XYZ colorspace
        var toXYZ = function (c) {
            var xR = c.r / 255.0;
            var xG = c.g / 255.0;
            var xB = c.b / 255.0;

            xR = xR > 0.04045 ? Math.pow((xR + 0.055) / 1.055, 2.4) : (xR / 12.92);
            xG = xG > 0.04045 ? Math.pow((xG + 0.055) / 1.055, 2.4) : (xG / 12.92);
            xB = xB > 0.04045 ? Math.pow((xB + 0.055) / 1.055, 2.4) : (xB / 12.92);

            xR = xR * 100;
            xG = xG * 100;
            xB = xB * 100;

            return {
                x: xR * 0.4124 + xG * 0.3576 + xB * 0.1805,
                y: xR * 0.2126 + xG * 0.7152 + xB * 0.0722,
                z: xR * 0.0193 + xG * 0.1192 + xB * 0.9505
            };
        };

        // Convert a color in the XYZ colorspace to the LAB colorspace
        var toLAB = function (c) {
            var xX = c.x / 95.047;
            var xY = c.y / 100.000;
            var xZ = c.z / 108.883;

            xX = xX > 0.008856 ? Math.pow(xX, 1.0 / 3) : (7.787 * xX) + (16.0 / 116);
            xY = xY > 0.008856 ? Math.pow(xY, 1.0 / 3) : (7.787 * xY) + (16.0 / 116);
            xZ = xZ > 0.008856 ? Math.pow(xZ, 1.0 / 3) : (7.787 * xZ) + (16.0 / 116);

            return {
                l: (116 * xY) - 16,
                a: 500 * (xX - xY),
                b: 200 * (xY - xZ)
            };
        };

        // Perform the comparison
        return eDelta(color1, color2);
    };

    var arrayContains = function (arr, obj) {
        for (var i = 0; i < arr.length; i++) {
            if (arr[i] === obj) {
                return true;
            }
        }
        return false;
    };

    var toColor = function (r, g, b) {
        return {
            r: r,
            g: g,
            b: b,
            a: 255
        };
    };

    var getRandomColor = function () {
        var r = Math.round(Math.random() * 200) + 55;
        var g;
        var b;
        while ((g = Math.round(Math.random() * 200) + 55) == r);
        while ((b = Math.round(Math.random() * 200) + 55) == r || b == g);
        return toColor(r, g, b);
    };

    var getPixel = function (image, x, y) {
        var i = x * 4 + y * 4 * image.width;
        var pixel = {
            r: image.data[i + 0],
            g: image.data[i + 1],
            b: image.data[i + 2]
        };
        return pixel;
    };

    var patternElementID = "cbl-pattern";
    var humanSolutionElementID = "cbl-solution";

    var closeClassifierDialog = function () {
        document.getElementById("cbl-trainer").style.display = "none";
    };

    var openClassifierDialog = function () {
        if (document.getElementById("cbl-trainer") != null) {
            document.getElementById("cbl-trainer").style.display = "flex";
        } else {
            var appendHtml = function (el, str) {
                var div = document.createElement('div');
                div.innerHTML = str;
                while (div.children.length > 0) {
                    el.appendChild(div.children[0]);
                }
            };

            appendHtml(document.body,
                '<div id="cbl-trainer">' +
                '    <div id="cbl-trainer-dialog">' +
                '        <span id="cbl-close" onclick="">&cross;</span>' +
                '        <h1>CBL-js Pattern Classifier</h1>' +
                '        <p>Identify the character in the image below by typing it into the textbox.</p>' +
                '        <p>Type <span class="cbl-discard">' + options.incorrect_segment_char + '</span> to discard a pattern if the image was not segmented properly.</p>' +
                '        <div class="cbl-row">' +
                '            <div class="cbl-cell-50 cbl-right">' +
                '                <img id="' + patternElementID + '" />' +
                '            </div>' +
                '            <div class="cbl-cell-50">' +
                '                <input id="' + humanSolutionElementID + '" type="text" />' +
                '            </div>' +
                '        </div>' +
                '    </div>' +
                '    <small><a href="https://github.com/skotz/cbl-js" target="_blank">CBL-js &copy; Scott Clayton</a></small>' +
                '</div>');

            document.getElementById("cbl-close").addEventListener("click", function (e) {
                closeClassifierDialog();
                e.preventDefault();
            });
        }
    };

    var log = function (message) {
        if (options.allow_console_log) {
            if (ACP_LOG_MODE) console.log("CBL: " + message);
        }
    };

    var warn = function (message) {
        if (options.allow_console_warn) {
            if (ACP_LOG_MODE) console.warn("CBL: " + message);
        }
    };

    // ZIP compression from https://github.com/pieroxy/lz-string
    var LZString = function () {
        function o(o, r) {
            if (!t[o]) {
                t[o] = {};
                for (var n = 0; n < o.length; n++) t[o][o.charAt(n)] = n
            }
            return t[o][r]
        }
        var r = String.fromCharCode,
            n = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
            e = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+-$",
            t = {},
            i = {
                compressToBase64: function (o) {
                    if (null == o) return "";
                    var r = i._compress(o, 6, function (o) {
                        return n.charAt(o)
                    });
                    switch (r.length % 4) {
                        default:
                        case 0:
                            return r;
                        case 1:
                            return r + "===";
                        case 2:
                            return r + "==";
                        case 3:
                            return r + "="
                    }
                },
                decompressFromBase64: function (r) {
                    return null == r ? "" : "" == r ? null : i._decompress(r.length, 32, function (e) {
                        return o(n, r.charAt(e))
                    })
                },
                compressToUTF16: function (o) {
                    return null == o ? "" : i._compress(o, 15, function (o) {
                        return r(o + 32)
                    }) + " "
                },
                decompressFromUTF16: function (o) {
                    return null == o ? "" : "" == o ? null : i._decompress(o.length, 16384, function (r) {
                        return o.charCodeAt(r) - 32
                    })
                },
                compressToUint8Array: function (o) {
                    for (var r = i.compress(o), n = new Uint8Array(2 * r.length), e = 0, t = r.length; t > e; e++) {
                        var s = r.charCodeAt(e);
                        n[2 * e] = s >>> 8, n[2 * e + 1] = s % 256
                    }
                    return n
                },
                decompressFromUint8Array: function (o) {
                    if (null === o || void 0 === o) return i.decompress(o);
                    for (var n = new Array(o.length / 2), e = 0, t = n.length; t > e; e++) n[e] = 256 * o[2 * e] + o[2 * e + 1];
                    var s = [];
                    return n.forEach(function (o) {
                        s.push(r(o))
                    }), i.decompress(s.join(""))
                },
                compressToEncodedURIComponent: function (o) {
                    return null == o ? "" : i._compress(o, 6, function (o) {
                        return e.charAt(o)
                    })
                },
                decompressFromEncodedURIComponent: function (r) {
                    return null == r ? "" : "" == r ? null : (r = r.replace(/ /g, "+"), i._decompress(r.length, 32, function (n) {
                        return o(e, r.charAt(n))
                    }))
                },
                compress: function (o) {
                    return i._compress(o, 16, function (o) {
                        return r(o)
                    })
                },
                _compress: function (o, r, n) {
                    if (null == o) return "";
                    var e, t, i, s = {},
                        p = {},
                        u = "",
                        c = "",
                        a = "",
                        l = 2,
                        f = 3,
                        h = 2,
                        d = [],
                        m = 0,
                        v = 0;
                    for (i = 0; i < o.length; i += 1)
                        if (u = o.charAt(i), Object.prototype.hasOwnProperty.call(s, u) || (s[u] = f++, p[u] = !0), c = a + u, Object.prototype.hasOwnProperty.call(s, c)) a = c;
                        else {
                            if (Object.prototype.hasOwnProperty.call(p, a)) {
                                if (a.charCodeAt(0) < 256) {
                                    for (e = 0; h > e; e++) m <<= 1, v == r - 1 ? (v = 0, d.push(n(m)), m = 0) : v++;
                                    for (t = a.charCodeAt(0), e = 0; 8 > e; e++) m = m << 1 | 1 & t, v == r - 1 ? (v = 0, d.push(n(m)), m = 0) : v++, t >>= 1
                                } else {
                                    for (t = 1, e = 0; h > e; e++) m = m << 1 | t, v == r - 1 ? (v = 0, d.push(n(m)), m = 0) : v++, t = 0;
                                    for (t = a.charCodeAt(0), e = 0; 16 > e; e++) m = m << 1 | 1 & t, v == r - 1 ? (v = 0, d.push(n(m)), m = 0) : v++, t >>= 1
                                }
                                l--, 0 == l && (l = Math.pow(2, h), h++), delete p[a]
                            } else
                                for (t = s[a], e = 0; h > e; e++) m = m << 1 | 1 & t, v == r - 1 ? (v = 0, d.push(n(m)), m = 0) : v++, t >>= 1;
                            l--, 0 == l && (l = Math.pow(2, h), h++), s[c] = f++, a = String(u)
                        } if ("" !== a) {
                        if (Object.prototype.hasOwnProperty.call(p, a)) {
                            if (a.charCodeAt(0) < 256) {
                                for (e = 0; h > e; e++) m <<= 1, v == r - 1 ? (v = 0, d.push(n(m)), m = 0) : v++;
                                for (t = a.charCodeAt(0), e = 0; 8 > e; e++) m = m << 1 | 1 & t, v == r - 1 ? (v = 0, d.push(n(m)), m = 0) : v++, t >>= 1
                            } else {
                                for (t = 1, e = 0; h > e; e++) m = m << 1 | t, v == r - 1 ? (v = 0, d.push(n(m)), m = 0) : v++, t = 0;
                                for (t = a.charCodeAt(0), e = 0; 16 > e; e++) m = m << 1 | 1 & t, v == r - 1 ? (v = 0, d.push(n(m)), m = 0) : v++, t >>= 1
                            }
                            l--, 0 == l && (l = Math.pow(2, h), h++), delete p[a]
                        } else
                            for (t = s[a], e = 0; h > e; e++) m = m << 1 | 1 & t, v == r - 1 ? (v = 0, d.push(n(m)), m = 0) : v++, t >>= 1;
                        l--, 0 == l && (l = Math.pow(2, h), h++)
                    }
                    for (t = 2, e = 0; h > e; e++) m = m << 1 | 1 & t, v == r - 1 ? (v = 0, d.push(n(m)), m = 0) : v++, t >>= 1;
                    for (;;) {
                        if (m <<= 1, v == r - 1) {
                            d.push(n(m));
                            break
                        }
                        v++
                    }
                    return d.join("")
                },
                decompress: function (o) {
                    return null == o ? "" : "" == o ? null : i._decompress(o.length, 32768, function (r) {
                        return o.charCodeAt(r)
                    })
                },
                _decompress: function (o, n, e) {
                    var t, i, s, p, u, c, a, l, f = [],
                        h = 4,
                        d = 4,
                        m = 3,
                        v = "",
                        w = [],
                        A = {
                            val: e(0),
                            position: n,
                            index: 1
                        };
                    for (i = 0; 3 > i; i += 1) f[i] = i;
                    for (p = 0, c = Math.pow(2, 2), a = 1; a != c;) u = A.val & A.position, A.position >>= 1, 0 == A.position && (A.position = n, A.val = e(A.index++)), p |= (u > 0 ? 1 : 0) * a, a <<= 1;
                    switch (t = p) {
                        case 0:
                            for (p = 0, c = Math.pow(2, 8), a = 1; a != c;) u = A.val & A.position, A.position >>= 1, 0 == A.position && (A.position = n, A.val = e(A.index++)), p |= (u > 0 ? 1 : 0) * a, a <<= 1;
                            l = r(p);
                            break;
                        case 1:
                            for (p = 0, c = Math.pow(2, 16), a = 1; a != c;) u = A.val & A.position, A.position >>= 1, 0 == A.position && (A.position = n, A.val = e(A.index++)), p |= (u > 0 ? 1 : 0) * a, a <<= 1;
                            l = r(p);
                            break;
                        case 2:
                            return ""
                    }
                    for (f[3] = l, s = l, w.push(l);;) {
                        if (A.index > o) return "";
                        for (p = 0, c = Math.pow(2, m), a = 1; a != c;) u = A.val & A.position, A.position >>= 1, 0 == A.position && (A.position = n, A.val = e(A.index++)), p |= (u > 0 ? 1 : 0) * a, a <<= 1;
                        switch (l = p) {
                            case 0:
                                for (p = 0, c = Math.pow(2, 8), a = 1; a != c;) u = A.val & A.position, A.position >>= 1, 0 == A.position && (A.position = n, A.val = e(A.index++)), p |= (u > 0 ? 1 : 0) * a, a <<= 1;
                                f[d++] = r(p), l = d - 1, h--;
                                break;
                            case 1:
                                for (p = 0, c = Math.pow(2, 16), a = 1; a != c;) u = A.val & A.position, A.position >>= 1, 0 == A.position && (A.position = n, A.val = e(A.index++)), p |= (u > 0 ? 1 : 0) * a, a <<= 1;
                                f[d++] = r(p), l = d - 1, h--;
                                break;
                            case 2:
                                return w.join("")
                        }
                        if (0 == h && (h = Math.pow(2, m), m++), f[l]) v = f[l];
                        else {
                            if (l !== d) return null;
                            v = s + s.charAt(0)
                        }
                        w.push(v), f[d++] = s + v.charAt(0), h--, s = v, 0 == h && (h = Math.pow(2, m), m++)
                    }
                }
            };
        return i
    }();
    "function" == typeof define && define.amd ? define(function () {
        return LZString
    }) : "undefined" != typeof module && null != module && (module.exports = LZString);

    // Load the model
    if (options.model_file.length) {
        obj.loadModel(options.model_file);
    } else if (options.model_string.length) {
        obj.loadModelString(options.model_string);
    }

    return obj;

};
