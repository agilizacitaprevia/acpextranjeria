function convertCSV2JSON(csv) {
    var options = {
        "char-delimiter": ",",
        "char-comments": "#",
        "char-quote": "\"",
        "convert-headers": true,
        "convert-skip-empty": true,
        "convert-dynamic-types": false,
        "formatting-spaces": true,
        "formatting-tabs": false,
        "formatting-none": false
    }
    
    var formatting = null;

    if (options["formatting-none"])
        formatting = 0;
    else if (options["formatting-tabs"])
        formatting = "\t";
    else if (options["formatting-spaces"])
        formatting = 2;

    var config = {
        delimiter: options["char-delimiter"] || ",",
        comments: options["char-comments"] || "#",
        quoteChar: options["char-quote"] || "\"",
        header: options["convert-headers"],
        skipEmptyLines: options["convert-skip-empty"],
        dynamicTyping: options["convert-dynamic-types"]
    }

    var result = Papa.parse(csv, config);
    // return JSON.stringify(result.data, null, formatting);
    return result.data;
}


function convertTSV2JSON(tsv) {
    var options = {
        "indent-use-spaces": true,
        "indent-spaces": "2",
        "indent-use-tabs": false,
        "indent-minify": false
    }

    if (options["indent-use-spaces"]) {
        var spaces = parseInt(options["indent-spaces"] || 2, 10);
    } else if (options['indent-minify']) {
        var spaces = 0;
    } else {
        var spaces = "\t";
    }
    var comments = options['char-comments'];
    var skipEmptyLines = options['convert-skip-empty'];

    tsv = tsv.replace("\r\n", "\n");
    var lines = tsv.split("\n");
    var data = [];
    var fields = [];
    for (var i = 0; i < lines.length; i++) {
        var line = lines[i];
        var cols = line.split("\t");
        if (cols.length == 1 && cols[0] == "" && skipEmptyLines) {
            continue;
        }
        if (cols.length && cols[0].indexOf(comments) == 0) {
            continue;
        }
        if (i == 0) {
            fields = cols;
        } else {
            var jsonObj = {};
            for (var j = 0; j < fields.length; j++) {
                jsonObj[fields[j]] = cols[j];
            }
            data.push(jsonObj);
        }
    }

    //var json = JSON.stringify(data, null, spaces);
    //return json;
    return data;
}


var tsv = `Factura	Fecha	Pedido	Referencia	Descripcion	Precio	Unidades	Precio de coste
12021/344974	02/07/2021	6012021539327	HEADER				`
